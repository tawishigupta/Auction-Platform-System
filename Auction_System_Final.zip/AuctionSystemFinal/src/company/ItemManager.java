package company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ItemManager {
    private JButton addItemsButton;
    private JButton updatePriceButton;
    private JPanel itemManagerPanel;
    JFrame itemManagerF=new JFrame();
public ItemManager() {
    itemManagerF.setContentPane(itemManagerPanel);
    itemManagerF.setVisible(true);
    itemManagerF.setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);
    itemManagerPanel.setBackground(new Color(187, 227, 237));
    addItemsButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            new  AddItem();
        }
    });
    updatePriceButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            new UpdatePrice();
        }
    });
}
}
