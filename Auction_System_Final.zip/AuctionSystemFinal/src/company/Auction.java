package company;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;
import java.util.Vector;

public class Auction extends AddItem{
    private JPanel auctionPanel;
    private JTable table1;
    private JButton startAuctionButton;
    private JLabel imageLabel;
    private JLabel timerLabel;
    public static String aNameData="",aPriceData="";
    public static ImageIcon aImageData;
    Timer timer;
    public static int sec = 60;
    JFrame auctionF=new JFrame();
public Auction() {
    auctionF.setContentPane(auctionPanel);
    auctionF.setVisible(true);
    auctionF.setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);
    auctionPanel.setBackground(new Color(187, 227, 237));
    tableData();
    startAuctionButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            startTimer();
            timer.start();
            JOptionPane.showMessageDialog(null,"Item put for auction and timer started");
            new UserSelect();

        }
    });
    table1.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent e) {
            DefaultTableModel dm = (DefaultTableModel)table1.getModel();
            int selectedRow = table1.getSelectedRow();
            aNameData=dm.getValueAt(selectedRow,0).toString();
            nameData.setText(aNameData);
            byte[] img = (byte[]) dm.getValueAt(selectedRow,1);
            ImageIcon imageIcon = new ImageIcon(img);
            Image im = imageIcon.getImage();
            Image newimg = im.getScaledInstance(200,200,Image.SCALE_SMOOTH);
            ImageIcon finalPic = new ImageIcon(newimg);
            aImageData = finalPic;
            imageLabel.setIcon(aImageData);
            aPriceData=dm.getValueAt(selectedRow,2).toString();
            priceData.setText(aPriceData);
        }
    });
}
    public void tableData() {
        try{
            String a= "Select * from auction where SOLD_AT IS NULL";
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/auction","root","root");
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(a);
            table1.setModel(buildTableModel(rs));
        }catch (Exception ex1){
            //JOptionPane.showMessageDialog(null,"Table data exception");
            ex1.printStackTrace();

        }
    }
    public static DefaultTableModel buildTableModel(ResultSet rs)
            throws SQLException {
        ResultSetMetaData metaData = rs.getMetaData();
// names of columns
        Vector<String> columnNames = new Vector<String>();
        int columnCount = metaData.getColumnCount();
        for (int column = 1; column <= columnCount; column++) {
            columnNames.add(metaData.getColumnName(column));
        }
// data of the table
        Vector<Vector<Object>> data = new Vector<Vector<Object>>();
        while (rs.next()) {
            Vector<Object> vector = new Vector<Object>();
            for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                vector.add(rs.getObject(columnIndex));
            }
            data.add(vector);
        }
        return new DefaultTableModel(data, columnNames);
    }
    public void startTimer(){
        timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sec--;
                if(sec==-1){
                    timer.stop();
                    tableData();
                }
                else if(sec>=0&&sec<10) timerLabel.setText("00:0"+sec);
                else timerLabel.setText("00:"+ sec);
            }
        });
    }
}
