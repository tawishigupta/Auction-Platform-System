package company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.lang.*;

public class Admin {
    private JButton addItemButton;
    private JButton showItemsButton;
    private JButton soldItemsButton;
    private JButton auctionButton;
    private JPanel adminPanel;
    JFrame adminF=new JFrame();
public Admin() {
    adminF.setContentPane(adminPanel);
    adminF.setVisible(true);
    adminF.setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);
    adminPanel.setBackground(new Color(187, 227, 237));
    addItemButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            new ItemManager();
        }
    });
    showItemsButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            new ShowItem();
        }
    });
    soldItemsButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            new SoldItem();
        }
    });
    auctionButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            new Auction();
        }
    });
}
}
