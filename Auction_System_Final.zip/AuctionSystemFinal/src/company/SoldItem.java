package company;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;
import java.util.Vector;

public class SoldItem extends AddItem{
    private JTable table1;
    private JButton OKButton;

    private JLabel imageLabel;
    private JPanel soldItemPanel;

    public static String adNameData="",adPriceData="";
    public static ImageIcon adImageData;

    JFrame soldItemF=new JFrame();
public SoldItem() {
    soldItemF.setContentPane(soldItemPanel);
    soldItemF.setVisible(true);
    soldItemF.setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);
    soldItemPanel.setBackground(new Color(187, 227, 237));
    OKButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            tableData();
        }
    });
    table1.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent e) {
            DefaultTableModel dm = (DefaultTableModel)table1.getModel();
            int selectedRow = table1.getSelectedRow();
            adNameData=dm.getValueAt(selectedRow,0).toString();
            nameData.setText(adNameData);
            byte[] img = (byte[]) dm.getValueAt(selectedRow,1);
            ImageIcon imageIcon = new ImageIcon(img);
            Image im = imageIcon.getImage();
            Image newimg = im.getScaledInstance(200,200,Image.SCALE_SMOOTH);
            ImageIcon finalPic = new ImageIcon(newimg);
            adImageData = finalPic;
            imageLabel.setIcon(adImageData);
            adPriceData=dm.getValueAt(selectedRow,2).toString();
            priceData.setText(adPriceData);
        }
    });
}
    public void tableData() {
        try{
            String a= "Select * from auction where SOLD_AT IS NOT NULL";
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/auction","root","root");
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(a);
            table1.setModel(buildTableModel(rs));
        }catch (Exception ex1){
            //JOptionPane.showMessageDialog(null,"Table data exception");
            ex1.printStackTrace();

        }
    }
    public static DefaultTableModel buildTableModel(ResultSet rs)
            throws SQLException {
        ResultSetMetaData metaData = rs.getMetaData();
// names of columns
        Vector<String> columnNames = new Vector<String>();
        int columnCount = metaData.getColumnCount();
        for (int column = 1; column <= columnCount; column++) {
            columnNames.add(metaData.getColumnName(column));
        }
// data of the table
        Vector<Vector<Object>> data = new Vector<Vector<Object>>();
        while (rs.next()) {
            Vector<Object> vector = new Vector<Object>();
            for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                vector.add(rs.getObject(columnIndex));
            }
            data.add(vector);
        }
        return new DefaultTableModel(data, columnNames);
    }
}
