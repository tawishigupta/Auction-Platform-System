package company;

public class LoginException extends Exception{
    String msg;
    LoginException(String msg) {

        super(msg);
        this.msg=msg;
    }
    @Override
    public String toString() {
        return msg;
    }
    public static void main(String[] args) {

        String username = "admin";
        String password = "admin";
        try {
            if(username!="admin" || password!="admin"){
                throw new LoginException("Invalid username or password");
            }
        }
        catch(LoginException ex) {
            //calls override toString() method
            System.out.println(ex);
            //prints message passed to the super constructor

        }
}

    }
