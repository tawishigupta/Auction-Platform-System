package company;
import company.roundercorners.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;


public class UserSelect {
    private JPanel selectPanel;
    private JButton customerButton;
    private JButton adminButton;
    private JLabel custImg;
    private JLabel adminImg;
    private JLabel custLabel;
    private JLabel adminLabel;
    public JPanel custPanel;
    private JPanel adminPanel;
    JFrame userF = new JFrame();


    public UserSelect() {

        userF.setContentPane(selectPanel);
        userF.setVisible(true);
        userF.setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);

        String custlabel = "<html><center>Select this user type if you<br>are looking to bid on any items</center></html>";
        String adminlabel = "<html><center>Select this user type if you<br>are the admin of the auction system</center></html>";
        custLabel.setText(custlabel);
        adminLabel.setText(adminlabel);


        selectPanel.setBackground(new Color(187, 227, 237));
        custPanel.setBorder(new RoundedPanel(50));


        custPanel.setBackground(Color.WHITE);
        custPanel.setPreferredSize(new Dimension(300, 300));
        adminPanel.setBorder(new RoundedPanel(50));


        adminPanel.setBackground(Color.WHITE);
        adminPanel.setPreferredSize(new Dimension(300, 300));


        custImg.setIcon(resize("C:/Users/shrav/Downloads/R.png"));
        adminImg.setIcon(resize("C:/Users/shrav/Downloads/Admin.png"));
        customerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Customer();
            }
        });
        adminButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                    new AdminLogin();
            }
        });
    }

    public ImageIcon resize(String path) {
        ImageIcon myImg = new ImageIcon(path);
        Image image = myImg.getImage();
        Image newImage = image.getScaledInstance(200, 200, Image.SCALE_SMOOTH);
        ImageIcon finalImage = new ImageIcon(newImage);
        return finalImage;
    }

    private static class RoundedBorder implements Border {

        private int radius;

        RoundedBorder(int radius) {
            this.radius = radius;
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(this.radius + 1, this.radius + 1, this.radius + 2, this.radius);
        }

        @Override
        public boolean isBorderOpaque() {
            return true;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            g.drawRoundRect(x, y, width - 1, height - 1, radius, radius);
        }
    }
}