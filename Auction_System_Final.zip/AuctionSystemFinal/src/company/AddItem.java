package company;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class AddItem {
    private JPanel addItemPanel;
    public JTextField nameData;
    public JTextField priceData;
    public JTextField path;
    private JButton OKButton;
    private JLabel imageLabel;
    private JButton selectImageButton;
    JFrame addItemF=new JFrame();
public AddItem() {
    addItemF.setVisible(true);
    addItemF.setContentPane(addItemPanel);
    addItemF.setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);
    addItemPanel.setBackground(new Color(187, 227, 237));
    OKButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if(nameData.getText().equals("")|| path.getText().equals("")|| priceData.getText().equals("")){
                JOptionPane.showMessageDialog(null,"Please Fill All Fields to add Record.");
            }else{
                String sql = "insert into auction (ITEM_NAME,IMAGE,PRICE)"+"values (?,?,?)";
                try {
                    File f = new File(path.getText());
                    InputStream inputStream = new FileInputStream(f);
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/auction","root","root");
                    PreparedStatement statement = connection.prepareStatement(sql);
                    statement.setString(1,nameData.getText());
                    statement.setBlob(2, inputStream);
                    statement.setString(3, priceData.getText());
                    statement.executeUpdate();
                    JOptionPane.showMessageDialog(null,"DETAILS ADDED SUCCESSFULLY");
                    nameData.setText("");
                    priceData.setText("");
                    imageLabel.setIcon(null);
                    path.setText("");
                }catch (Exception ex){
                    // JOptionPane.showMessageDialog(null,"add item exception");
                    ex.printStackTrace();
                }

            }

        }
    });
    selectImageButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            JFileChooser fileChooser = new JFileChooser();
            FileNameExtensionFilter filter = new FileNameExtensionFilter("*.IMAGE","jpg","png");
            fileChooser.addChoosableFileFilter(filter);
            int rs = fileChooser.showSaveDialog(null);
            if(rs==JFileChooser.APPROVE_OPTION){
                File selectedImage = fileChooser.getSelectedFile();
                path.setText(selectedImage.getAbsolutePath());
                imageLabel.setIcon(resize(path.getText()));
            }
        }
    });
}
    public ImageIcon resize(String path){
        ImageIcon myImg = new ImageIcon(path);
        Image image = myImg.getImage();
        Image newImage = image.getScaledInstance(200,200,Image.SCALE_SMOOTH);
        ImageIcon finalImage = new ImageIcon(newImage);
        return finalImage;
    }
}
