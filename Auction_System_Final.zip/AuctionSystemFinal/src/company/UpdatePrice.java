package company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class UpdatePrice {
    private JTextField textField1;
    private JTextField textField2;
    private JButton updateButton;
    private JPanel updatePanel;
    JFrame updateF=new JFrame();
public UpdatePrice() {
    updateF.setVisible(true);
    updateF.setContentPane(updatePanel);
    updateF.setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);
    updatePanel.setBackground(new Color(187, 227, 237));
    updateButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {

            String name=textField1.getText();
            String price=textField2.getText();
           try{

                int price1=Integer.parseInt(price);


                String sql = "UPDATE auction set price="+price1+" where ITEM_NAME='"+name+"'";
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/auction","root","root");
                PreparedStatement statement = connection.prepareStatement(sql);
                statement.executeUpdate();
                JOptionPane.showMessageDialog(null,"Price updated successfully");
            }
        catch (Exception ex) {
                System.out.println(ex);
            }



        }
    });
}
}
