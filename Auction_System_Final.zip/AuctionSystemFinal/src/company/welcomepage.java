package company;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class welcomepage {
    private JPanel panel1;
    private JButton WELCOMEButton;

    JFrame fr=new JFrame();
public welcomepage() {
    fr.setVisible(true);
    fr.setContentPane(panel1);
    fr.pack();
    WELCOMEButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            new UserSelect();
        }
    });
}
}
