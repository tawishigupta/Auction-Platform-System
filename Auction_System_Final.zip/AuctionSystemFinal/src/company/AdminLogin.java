package company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Arrays;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;

public class AdminLogin {
    private JPanel adminLoginPanel;
    private JTextField textField1;
    private JPasswordField passwordField1;
    private JButton loginButton;
    public Image img;
    JFrame adminLoginF=new JFrame();
public AdminLogin() {
    img = Toolkit.getDefaultToolkit().getImage("C:/Users/dipes/Downloads/bg1.jpg");
    adminLoginF.setVisible(true);
    adminLoginF.setContentPane(adminLoginPanel);
    adminLoginF.setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);
    adminLoginPanel.setBackground(new Color(187, 227, 237));
    String username = "admin";
    String password = "admin";
    char[] pwd = password.toCharArray();
    loginButton.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e) {
            if(username.equals(textField1.getText())&& Arrays.equals(pwd,passwordField1.getPassword())){
                System.out.println("before");
                new Admin();
                System.out.println("after");
            }
            else{
                if(Character.isDigit(textField1.getText().charAt(0)))
                {
                    try {
                        JOptionPane.showMessageDialog(adminLoginPanel,"Username cannot start with a number!");
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }

        }
    });

}

}

